import numpy as np
from losses import mse
class RunningMetric(object):
    def __init__(self, metric_type):
        self._metric_type = metric_type
        if metric_type == 'mse':
            self.mse = 0.0
            self.num_updates = 0.0

    def reset(self):
        if self._metric_type == 'mse':
            self.mse = 0.0
            self.num_updates = 0.0

    def update(self, pred, gt):
        if self._metric_type == 'mse':
            self.mse += np.mean(np.square(pred.data.cpu().numpy() - gt.data.cpu().numpy()))
            self.num_updates += 1

    def get_result(self):
        if self._metric_type == 'mse':
            return {'mse': self.mse/self.num_updates}

def get_metrics(params):
    met = {}
    if 'shuizhi' in params['dataset']:
        for t in params['tasks']:
            met[t] = RunningMetric(metric_type = 'mse')
    return met