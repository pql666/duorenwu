import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

class CNN_BiLSTM(nn.Module):
    def __init__(self, feature_size, hidden_size, num_layers, kernel_size, out_channels, dropout):
        super(CNN_BiLSTM, self).__init__()

        self.hidden_dim = hidden_size
        self.num_layers = num_layers

        self.conv1 = nn.Conv1d(in_channels=feature_size, out_channels=out_channels[0], kernel_size=kernel_size, stride=1, padding=0)


        self.conv2 = nn.Conv1d(out_channels[0], out_channels[1], kernel_size, stride=1, padding=0)


        self.dropout = nn.Dropout(dropout)
        self.bilstm = nn.LSTM(out_channels[1], hidden_size, num_layers=num_layers, batch_first=True, bidirectional=True)

    def forward(self, x):
        # 输入：[batch_size, feature_dim, seq_len]
        x = x.transpose(1, 2)  # 调整维度为：[batch_size, seq_len, feature_dim]

        # CNN层
        x = self.conv1(x)

        x = self.conv2(x)

        x = self.dropout(x)

        # BiLSTM层
        h0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_size).to(x.device)

        out, (_, _) = self.bilstm(x, (h0, c0))

        return out


class Attention(nn.Module):
    def __init__(self, hidden_size):
        super(Attention, self).__init__()

        self.hidden_size = hidden_size
        self.attn_weights = nn.Parameter(torch.randn(hidden_size), requires_grad=True)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # 计算注意力系数
        attn_scores = torch.matmul(x, self.attn_weights)
        attn_weights = F.softmax(attn_scores, dim=1)

        # 加权汇总各时间步的隐层状态，得到最终表示
        context_vector = torch.sum(attn_weights[:, :, None] * x, dim=1)

        # 将注意力加权后的特征向量传入全连接层进行线性转换
        out = self.fc(context_vector)

        return out

