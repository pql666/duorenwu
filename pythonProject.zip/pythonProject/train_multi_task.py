import sys
import torch
import click
import json
import datetime
from timeit import default_timer as timer

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.utils import data
import torchvision
import types

from tqdm import tqdm
from tensorboardX import SummaryWriter

import losses
import datasets
import metrics
import model_selector
from min_norm_solvers import MinNormSolver, gradient_normalizers

NUM_EPOCHS= 10

def train_multi_task(param_file):
    with open('configs.json') as config_params:
        configs = json.load(config_params)

    with open(param_file) as json_params:
        params = json.load(json_params)

    exp_identifier = []
    for (key, val) in params.items():
        if 'tasks' in key:
            continue
        exp_identifier += ['{}={}'.format(key, val)]

    exp_identifier = '|'.join(exp_identifier)
    params['exp_id'] = exp_identifier

    writer = SummaryWriter(
        log_dir='runs/{}_{}'.format(params['exp_id'], datetime.datetime.now().strftime("%I:%M%p on %B %d, %Y")))

    train_loader, train_dst, val_loader, val_dst = datasets.get_dataset(params, configs)
    loss_fn = losses.get_loss(params)
    metric = metrics.get_metrics(params)

    model = model_selector.get_model(params)
    model_params = []
    for m in model:
        model_params += model[m].parameters()

    if 'Adam' in params['optimizer']:
        optimizer = torch.optim.Adam(model_params, lr=params['lr'])

    tasks = params['tasks']
    all_tasks = configs[params['dataset']]['all_tasks']
    print('Starting training with parameters \n \t{} \n'.format(str(params)))

    if 'mgda' in params['algorithm']:
        approximate_norm_solution = params['use_approximation']
        if approximate_norm_solution:
            print('Using approximate min-norm solver')
        else:
            print('Using full solver')
    n_iter = 0

    for m in model:
        model[m].train()

    for batch in train_loader:
        n_iter += 1
        # First member is always images
        images = batch[0]
        images = Variable(images.cuda())

        labels = {}
        # Read all targets of all tasks
        for i, t in enumerate(all_tasks):
            if t not in tasks:
                   continue
            labels[t] = batch[i + 1]
            labels[t] = Variable(labels[t].cuda())



        loss_data = {}
        grads = {}
        scale = {}

        if 'mgda' in params['algorithm']:
            # Will use our MGDA_UB if approximate_norm_solution is True. Otherwise, will use MGDA

            if approximate_norm_solution:
                optimizer.zero_grad()
                # First compute representations (z)
                images_volatile = Variable(images.data, volatile=True)
                rep = model['rep'](images_volatile)
                # As an approximate solution we only need gradients for input
                if isinstance(rep, list):
                    # This is a hack to handle psp-net
                    rep = rep[0]
                    rep_variable = [Variable(rep.data.clone(), requires_grad=True)]
                    list_rep = True
                else:
                    rep_variable = Variable(rep.data.clone(), requires_grad=True)
                    list_rep = False

                # Compute gradients of each loss function wrt z
                for t in tasks:
                    optimizer.zero_grad()
                    out_t = model[t](rep_variable)
                    loss = loss_fn[t](out_t, labels[t])
                    loss_data[t] = loss.data[0]
                    loss.backward()
                    grads[t] = []
                    if list_rep:
                        grads[t].append(Variable(rep_variable[0].grad.data.clone(), requires_grad=False))
                        rep_variable[0].grad.data.zero_()
                    else:
                        grads[t].append(Variable(rep_variable.grad.data.clone(), requires_grad=False))
                        rep_variable.grad.data.zero_()

            gn = gradient_normalizers(grads, loss_data, params['normalization_type'])
            for t in tasks:
                for gr_i in range(len(grads[t])):
                    grads[t][gr_i] = grads[t][gr_i] / gn[t]

            # Frank-Wolfe iteration to compute scales.
            sol, min_norm = MinNormSolver.find_min_norm_element([grads[t] for t in tasks])
            for i, t in enumerate(tasks):
                scale[t] = float(sol[i])
        else:
            for t in tasks:
                scale[t] = float(params['scales'][t])

            # Scaled back-propagation
        optimizer.zero_grad()
        rep = model['rep'](images)
        for i, t in enumerate(tasks):
            out_t = model[t](rep)
            loss_t = loss_fn[t](out_t, labels[t])
            loss_data[t] = loss_t.data[0]
            if i > 0:
                loss = loss + scale[t] * loss_t
            else:
                loss = scale[t] * loss_t
        loss.backward()
        optimizer.step()

        writer.add_scalar('training_loss', loss.data[0], n_iter)
        for t in tasks:
            writer.add_scalar('training_loss_{}'.format(t), loss_data[t], n_iter)

    for m in model:
        model[m].eval()

    tot_loss = {}
    tot_loss['all'] = 0.0
    met = {}
    for t in tasks:
        tot_loss[t] = 0.0
        met[t] = 0.0

    num_val_batches = 0
    for batch_val in val_loader:
        val_images = Variable(batch_val[0].cuda(), volatile=True)
        labels_val = {}

        for i, t in enumerate(all_tasks):
            if t not in tasks:
                continue
            labels_val[t] = batch_val[i + 1]
            labels_val[t] = Variable(labels_val[t].cuda(), volatile=True)

        val_rep = model['rep'](val_images)
        for t in tasks:
            out_t_val = model[t](val_rep)
            loss_t = loss_fn[t](out_t_val, labels_val[t])
            tot_loss['all'] += loss_t.data[0]
            tot_loss[t] += loss_t.data[0]
            metric[t].update(out_t_val, labels_val[t])
        num_val_batches += 1

    for t in tasks:
        writer.add_scalar('validation_loss_{}'.format(t), tot_loss[t] / num_val_batches, n_iter)
        metric_results = metric[t].get_result()
        for metric_key in metric_results:
            writer.add_scalar('metric_{}_{}'.format(metric_key, t), metric_results[metric_key], n_iter)
        metric[t].reset()
    writer.add_scalar('validation_loss', tot_loss['all'] / len(val_dst), n_iter)


if __name__ == '__main__':
    train_multi_task()

