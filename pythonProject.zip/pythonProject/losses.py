import torch
import torch.nn.functional as F

def mse(y_pred, y_true):
    return F.mse_loss(y_pred, y_true)

def get_loss(params):
    if 'shuizhi' in params['dataset']:
        loss_fn = {}
        for t in params['tasks']:
            loss_fn[t] = mse
        return loss_fn