from models import CNN_BiLSTM, Attention

def get_model(params):
    data = params['dataset']
    if 'shuizhi' in data:
        model = {}
        model['rep'] = CNN_BiLSTM(4, 256, 1, 3,[32, 64], 0.3)
        model['rep'].cuda()
        for t in params['tasks']:
            model[t] = Attention(512)
            model[t].cuda()
        return model